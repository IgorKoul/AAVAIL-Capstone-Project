# aavail-revenue-forecast

This is a functional machine learning revenue forecasts model Flask app that can be deployed on Docker.

To run the app, clone the git and run:
```bash
$ pip install -U flask
$ pip install -U plotly
$ python run app.py # run on 127.0.0.1:8080
```